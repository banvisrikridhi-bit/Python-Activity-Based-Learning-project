products = [
    ("Rice", "Grocery", 1200, 2),
    ("Headphones", "Electronics", 1800, 2),
    ("Shirt", "Clothing", 900, 1)
]
tax_rates = {"Grocery": 0.05, "Electronics": 0.18, "Clothing": 0.12}

subtotal = sum(price * qty for _, _, price, qty in products)
discount = min(subtotal * 0.10, 1000) if subtotal >= 5000 else 0
factor = (subtotal - discount) / subtotal if subtotal else 1
tax_total = 0

print("RETAIL INVOICE")
for name, category, price, qty in products:
    line = price * qty
    taxable_line = line * factor
    tax = taxable_line * tax_rates[category]
    tax_total += tax
    print(f"{name}: {qty} x Rs.{price} = Rs.{line:.2f} | Tax Rs.{tax:.2f}")

print(f"Subtotal: Rs.{subtotal:.2f}")
print(f"Discount: Rs.{discount:.2f}")
print(f"Tax: Rs.{tax_total:.2f}")
print(f"Grand Total: Rs.{subtotal - discount + tax_total:.2f}")
