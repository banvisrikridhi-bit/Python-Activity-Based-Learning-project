stock_records = [
    ("Pen", 500, 200, 150, 540, 600),
    ("Notebook", 300, 100, 80, 310, 400),
    ("Marker", 120, 50, 40, 125, 150)
]

print("WAREHOUSE INVENTORY RECONCILIATION")
for name, opening, received, dispatched, physical, target in stock_records:
    expected = opening + received - dispatched
    discrepancy = physical - expected
    replenishment = max(0, target - physical)
    status = "MATCH" if discrepancy == 0 else "DISCREPANCY"
    print(f"{name}: Expected={expected}, Physical={physical}, "
          f"Difference={discrepancy}, Status={status}, "
          f"Reorder={replenishment}")
