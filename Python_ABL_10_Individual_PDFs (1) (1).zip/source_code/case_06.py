def distance_fare(km):
    first = min(km, 100) * 0.75
    second = max(0, min(km - 100, 200)) * 0.60
    third = max(0, km - 300) * 0.45
    return first + second + third

passengers = [
    ("Meena", 35, 250, "Sleeper"),
    ("Arjun", 65, 350, "AC"),
    ("Tara", 10, 120, "Sleeper")
]
class_rate = {"Sleeper": 1.0, "AC": 2.0}

print("RAILWAY FARE SUMMARY")
for name, age, km, travel_class in passengers:
    fare = distance_fare(km) * class_rate[travel_class]
    if 5 <= age <= 11:
        fare *= 0.50
    elif age >= 60:
        fare *= 0.80
    total = fare + 40
    penalty = total * 0.25
    refund = total - penalty
    print(f"{name}: Fare Rs.{total:.2f} | Cancellation Rs.{penalty:.2f} | Refund Rs.{refund:.2f}")
