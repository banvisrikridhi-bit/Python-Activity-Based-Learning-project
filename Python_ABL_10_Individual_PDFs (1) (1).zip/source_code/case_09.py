rates = {"USD": 83.0, "EUR": 90.0, "GBP": 105.0}
expenses = [
    ("Hotel", "USD", 300),
    ("Food", "EUR", 180),
    ("Transport", "GBP", 80),
    ("Shopping", "USD", 150)
]
budget = 100000
category_totals = {}
grand_total = 0

print("TRAVEL EXPENSE REPORT (INR)")
for category, currency, amount in expenses:
    converted = amount * rates[currency]
    fee = converted * 0.02
    total = converted + fee
    category_totals[category] = total
    grand_total += total
    print(f"{category}: Rs.{total:.2f} (including 2% fee)")

largest = max(category_totals, key=category_totals.get)
print(f"Total spending: Rs.{grand_total:.2f}")
print(f"Budget: Rs.{budget:.2f}")
print(f"Remaining: Rs.{budget - grand_total:.2f}")
print(f"Largest category: {largest}")
