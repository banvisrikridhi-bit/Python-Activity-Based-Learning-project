def calculate_bill(units):
    if units <= 100:
        energy = units * 1.50
    elif units <= 200:
        energy = 100 * 1.50 + (units - 100) * 2.50
    else:
        energy = 100 * 1.50 + 100 * 2.50 + (units - 200) * 4.00
    if units <= 100:
        energy *= 0.95
    return energy + 50

monthly_units = [80, 120, 260]
previous_bill = None
print("MONTHLY ELECTRICITY BILL")
for month, units in enumerate(monthly_units, 1):
    bill = calculate_bill(units)
    print(f"Month {month}: {units} units -> Rs.{bill:.2f}")
    if previous_bill is not None:
        change = (bill - previous_bill) / previous_bill * 100
        if change > 30:
            print(f"  ALERT: Bill increased by {change:.1f}%")
    previous_bill = bill
