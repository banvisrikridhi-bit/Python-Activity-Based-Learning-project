conducted = 80
attended = 54
threshold = 75

if conducted <= 0 or attended < 0 or attended > conducted:
    print("Invalid attendance data")
else:
    percentage = attended / conducted * 100
    print(f"Current attendance: {percentage:.2f}%")
    if percentage >= threshold:
        print("Status: Eligible")
        print("Additional classes required: 0")
    else:
        extra = 0
        while (attended + extra) / (conducted + extra) * 100 < threshold:
            extra += 1
        print("Status: Not eligible yet")
        print("Additional consecutive classes to attend:", extra)
        print(f"Projected attendance: {(attended + extra)/(conducted + extra)*100:.2f}%")
