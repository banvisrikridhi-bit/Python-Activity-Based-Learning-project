students = ["Asha", "Bharat", "Charan", "Divya"]
subjects = ["Python", "Maths", "Physics"]
marks = [
    [88, 76, 91],
    [65, 72, 68],
    [45, 50, 48],
    [92, 89, 94]
]

totals = []
print("STUDENT-WISE PERFORMANCE")
for name, row in zip(students, marks):
    total = sum(row)
    average = total / len(subjects)
    totals.append(total)
    print(f"{name}: Total={total}, Average={average:.2f}")

print("\nSUBJECT-WISE AVERAGES")
for col, subject in enumerate(subjects):
    average = sum(row[col] for row in marks) / len(students)
    status = "LOW" if average < 50 else "OK"
    print(f"{subject}: {average:.2f} ({status})")

top_index = totals.index(max(totals))
print(f"Top performer: {students[top_index]} ({totals[top_index]} marks)")
