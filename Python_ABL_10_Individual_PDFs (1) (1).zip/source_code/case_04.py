name = "Ravi"
basic = 30000
overtime_hours = 5
incentive = 2000

hra = basic * 0.20
travel = basic * 0.10
overtime = overtime_hours * 200
gross = basic + hra + travel + overtime + incentive

if gross <= 30000:
    deduction = gross * 0.05
elif gross <= 50000:
    deduction = 30000 * 0.05 + (gross - 30000) * 0.10
else:
    deduction = (30000 * 0.05 + 20000 * 0.10
                 + (gross - 50000) * 0.15)

net = gross - deduction
print("EMPLOYEE SALARY STATEMENT")
print("Employee:", name)
print(f"Basic Pay: Rs.{basic:.2f}")
print(f"HRA: Rs.{hra:.2f}")
print(f"Travel Allowance: Rs.{travel:.2f}")
print(f"Overtime: Rs.{overtime:.2f}")
print(f"Incentive: Rs.{incentive:.2f}")
print(f"Gross Salary: Rs.{gross:.2f}")
print(f"Deduction: Rs.{deduction:.2f}")
print(f"Net Salary: Rs.{net:.2f}")
