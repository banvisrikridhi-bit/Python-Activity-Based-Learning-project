classes = [
    ("Python", "Monday", 900, 1000, "Lab-1"),
    ("Mathematics", "Monday", 930, 1030, "Room-2"),
    ("Physics", "Monday", 1100, 1200, "Lab-1"),
    ("English", "Tuesday", 900, 1000, "Room-2"),
    ("Chemistry", "Monday", 930, 1015, "Lab-1")
]

conflicts = 0
print("TIMETABLE CONFLICT REPORT")
for i in range(len(classes)):
    for j in range(i + 1, len(classes)):
        a, b = classes[i], classes[j]
        overlap = (a[1] == b[1] and a[2] < b[3] and b[2] < a[3])
        if overlap:
            conflicts += 1
            print(f"{a[0]} conflicts with {b[0]} on {a[1]}")
            if a[4] == b[4]:
                print(f"  ROOM CLASH: {a[4]} is double-booked")

if conflicts == 0:
    print("No timetable conflicts found.")
else:
    print("Total overlapping pairs:", conflicts)
