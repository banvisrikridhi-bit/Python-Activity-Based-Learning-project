applicants = [
    ("Asha", 92, 88, 90, 96, 180000),
    ("Bharat", 86, 82, 84, 92, 220000),
    ("Charan", 95, 70, 92, 98, 150000),
    ("Divya", 89, 91, 87, 90, 300000)
]

eligible = []
for name, m1, m2, m3, attendance, income in applicants:
    aggregate = (m1 + m2 + m3) / 3
    if (aggregate >= 85 and min(m1, m2, m3) >= 75
            and attendance >= 90 and income <= 250000):
        eligible.append((name, aggregate, attendance))

eligible.sort(key=lambda item: (item[1], item[2]), reverse=True)

print("SCHOLARSHIP ELIGIBILITY REPORT")
if eligible:
    for rank, (name, aggregate, attendance) in enumerate(eligible, 1):
        print(f"{rank}. {name} | Aggregate: {aggregate:.2f}% | Attendance: {attendance}%")
else:
    print("No applicant satisfies all conditions.")
