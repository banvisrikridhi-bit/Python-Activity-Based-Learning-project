PYTHON ABL - 10 INDIVIDUAL ASSIGNMENT PDFs

Contents:
- 10 individual PDF reports
- source_code/: corresponding runnable Python .py files
- screenshots/: recreated VS Code-style editor and terminal output images

The PDFs contain no blank student-detail fields, signature lines, or other fill-in placeholders.
The screenshots are illustrative VS Code-style recreations. The output shown was produced by executing the Python programs in this package, but the images were not captured from the student's own VS Code installation.

Selected case studies:
1 University Scholarship Allocation
2 Progressive Electricity Billing
4 Employee Payroll and Deduction Analysis
6 Railway Fare and Reservation Calculator
7 Retail Billing with Multiple Discount Rules
9 Multi-Currency Travel Budget Analysis
12 Attendance Recovery Computation
14 Warehouse Inventory Reconciliation
23 Student Timetable Conflict Detection
42 Student Marks Matrix Analysis
